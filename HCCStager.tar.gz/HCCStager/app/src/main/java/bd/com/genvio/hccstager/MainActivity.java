package bd.com.genvio.hccstager;

import android.app.Dialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Dialog myDialog;
    RadioButton encephalopathyRadio1, encephalopathyRadio2, encephalopathyRadio3,
            ascitesRadio1, ascitesRadio2, ascitesRadio3,
            albuminRadio1, albuminRadio2, albuminRadio3,
            prothrombinRadio1, prothrombinRadio2, prothrombinRadio3, prothrombinRadio4, prothrombinRadio5, prothrombinRadio6,
            bilirubinRadio1, bilirubinRadio2, bilirubinRadio3, bilirubinRadio4, bilirubinRadio5, bilirubinRadio6,
            classARadio1, classBRadio2, classCRadio3,
            noduleRadio1, noduleRadio2, noduleRadio3, noduleRadio4, noduleRadio5,
            portalRadio1, portalRadio2,
            RLNMRadio1, RLNMRadio2,
            DMRadio1, DMRadio2,
            EPRadio1, EPRadio2, EPRadio3;

    Button classify, getStage;

    RadioGroup encephalopathyRadioGroup, ascitesRadioGroup, albuminRadioGroup, prothrombinRadioGroup, bilirubinRadioGroup,
            childPughRadioGroup, noduleRadioGroup, portalVeinInvasionRadioGroup, RLNMRadioGroup, DMRadioGroup, EPRadioGroup;

    public int count = 0, pughScore = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TabHost tabHost = findViewById(R.id.tabHost);
        tabHost.setup();

        //tab1
        TabHost.TabSpec spec = tabHost.newTabSpec("Child Pugh Score");
        spec.setContent(R.id.child_Pugh_Score);
        spec.setIndicator("Child Pugh Score");
        tabHost.addTab(spec);

        //tab2
        spec = tabHost.newTabSpec("HCC Staging");
        spec.setContent(R.id.hcc_Staging);
        spec.setIndicator("HCC Staging");
        tabHost.addTab(spec);

        myDialog = new Dialog(this);



        /**
         * All variables
         */
        encephalopathyRadioGroup = findViewById(R.id.encephalopathyRadioGroup);
        encephalopathyRadio1 = findViewById(R.id.encephalopathyRadio1);
        encephalopathyRadio2 = findViewById(R.id.encephalopathyRadio2);
        encephalopathyRadio3 = findViewById(R.id.encephalopathyRadio3);

        ascitesRadioGroup = findViewById(R.id.ascitesRadioGroup);
        ascitesRadio1 = findViewById(R.id.ascitesRadio1);
        ascitesRadio2 = findViewById(R.id.ascitesRadio2);
        ascitesRadio3 = findViewById(R.id.ascitesRadio3);

        albuminRadioGroup = findViewById(R.id.albuminRadioGroup);
        albuminRadio1 = findViewById(R.id.albuminRadio1);
        albuminRadio2 = findViewById(R.id.albuminRadio2);
        albuminRadio3 = findViewById(R.id.albuminRadio3);

        prothrombinRadioGroup = findViewById(R.id.prothrombinRadioGroup);
        prothrombinRadio1 = findViewById(R.id.prothrombinRadio1);
        prothrombinRadio2 = findViewById(R.id.prothrombinRadio2);
        prothrombinRadio3 = findViewById(R.id.prothrombinRadio3);
        prothrombinRadio4 = findViewById(R.id.prothrombinRadio4);
        prothrombinRadio5 = findViewById(R.id.prothrombinRadio5);
        prothrombinRadio6 = findViewById(R.id.prothrombinRadio6);

        bilirubinRadioGroup = findViewById(R.id.bilirubinRadioGroup);
        bilirubinRadio1 = findViewById(R.id.bilirubinRadio1);
        bilirubinRadio2 = findViewById(R.id.bilirubinRadio2);
        bilirubinRadio3 = findViewById(R.id.bilirubinRadio3);
        bilirubinRadio4 = findViewById(R.id.bilirubinRadio4);
        bilirubinRadio5 = findViewById(R.id.bilirubinRadio5);
        bilirubinRadio6 = findViewById(R.id.bilirubinRadio6);

        childPughRadioGroup = findViewById(R.id.childPughRadioGroup);
        classARadio1 = findViewById(R.id.classARadio1);
        classBRadio2 = findViewById(R.id.classBRadio2);
        classCRadio3 = findViewById(R.id.classCRadio3);

        noduleRadioGroup = findViewById(R.id.noduleRadioGroup);
        noduleRadio1 = findViewById(R.id.noduleRadio1);
        noduleRadio2 = findViewById(R.id.noduleRadio2);
        noduleRadio3 = findViewById(R.id.noduleRadio3);
        noduleRadio4 = findViewById(R.id.noduleRadio4);
        noduleRadio5 = findViewById(R.id.noduleRadio5);

        portalVeinInvasionRadioGroup = findViewById(R.id.portalVeinInvasionRadioGroup);
        portalRadio1 = findViewById(R.id.portalRadio1);
        portalRadio2 = findViewById(R.id.portalRadio2);

        RLNMRadioGroup = findViewById(R.id.RLNMRadioGroup);
        RLNMRadio1 = findViewById(R.id. RLNMRadio1);
        RLNMRadio2 = findViewById(R.id.RLNMRadio2);

        DMRadioGroup = findViewById(R.id.DMRadioGroup);
        DMRadio1 = findViewById(R.id.DMRadio1);
        DMRadio2 = findViewById(R.id.DMRadio2);

        EPRadioGroup = findViewById(R.id.EPRadioGroup);
        EPRadio1 = findViewById(R.id.EPRadio1);
        EPRadio2 = findViewById(R.id.EPRadio2);
        EPRadio3 = findViewById(R.id.EPRadio3);


        classify = findViewById(R.id.classify);
        getStage = findViewById(R.id.getStage);

        /**
        * On click listener for classify button
         */
        classify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Encephalopathy
                if (encephalopathyRadioGroup.getCheckedRadioButtonId() != -1){

                    int id = encephalopathyRadioGroup.getCheckedRadioButtonId();

                    switch (id){
                        case R.id.encephalopathyRadio1:
                            count+=1;
                            break;
                        case R.id.encephalopathyRadio2:
                            count+=2;
                            break;
                        case R.id.encephalopathyRadio3:
                            count+=3;
                            break;
                        default:
                             Toast.makeText(MainActivity.this, "Radio not Clicked", Toast.LENGTH_SHORT).show();
                             break;
                    }
                }

                // Ascites
                if (ascitesRadioGroup.getCheckedRadioButtonId() != -1){

                    int id = ascitesRadioGroup.getCheckedRadioButtonId();

                    switch (id){
                        case R.id.ascitesRadio1:
                            count+=1;
                            break;
                        case R.id.ascitesRadio2:
                            count+=2;
                            break;
                        case R.id.ascitesRadio3:
                            count+=3;
                            break;
                        default:
                            Toast.makeText(MainActivity.this, "Radio not Clicked", Toast.LENGTH_SHORT).show();
                            break;
                    }
                }
                // Albumin
                if (albuminRadioGroup.getCheckedRadioButtonId() != -1){

                    int id = albuminRadioGroup.getCheckedRadioButtonId();

                    switch (id){
                        case R.id.albuminRadio1:
                            count+=1;
                            break;
                        case R.id.albuminRadio2:
                            count+=2;
                            break;
                        case R.id.albuminRadio3:
                            count+=3;
                            break;
                        default:
                            Toast.makeText(MainActivity.this, "Radio not Clicked", Toast.LENGTH_SHORT).show();
                            break;
                    }
                }

                // Prothrombin
                if (prothrombinRadioGroup.getCheckedRadioButtonId() != -1){

                    int id = prothrombinRadioGroup.getCheckedRadioButtonId();

                    switch (id){
                        case R.id.prothrombinRadio1:
                            count+=1;
                            break;
                        case R.id.prothrombinRadio2:
                            count+=2;
                            break;
                        case R.id.prothrombinRadio3:
                            count+=3;
                            break;
                        case R.id.prothrombinRadio4:
                            count+=1;
                            break;
                        case R.id.prothrombinRadio5:
                            count+=2;
                            break;
                        case R.id.prothrombinRadio6:
                            count+=3;
                            break;
                        default:
                            Toast.makeText(MainActivity.this, "Radio not Clicked", Toast.LENGTH_SHORT).show();
                            break;
                    }
                }

                // Bilirubin
                if (bilirubinRadioGroup.getCheckedRadioButtonId() != -1){

                    int id = bilirubinRadioGroup.getCheckedRadioButtonId();

                    switch (id){
                        case R.id.bilirubinRadio1:
                            count+=1;
                            break;
                        case R.id.bilirubinRadio2:
                            count+=2;
                            break;
                        case R.id.bilirubinRadio3:
                            count+=3;
                            break;
                        case R.id.bilirubinRadio4:
                            count+=1;
                            break;
                        case R.id.bilirubinRadio5:
                            count+=2;
                            break;
                        case R.id.bilirubinRadio6:
                            count+=3;
                            break;
                        default:
                            Toast.makeText(MainActivity.this, "Radio not Clicked", Toast.LENGTH_SHORT).show();
                            break;
                    }
                }

                if(count<5){
                    Toast toast = Toast.makeText(MainActivity.this, "Please check all the options.", Toast.LENGTH_SHORT);
                    toast.show();
                    toast.setGravity(Gravity.TOP|Gravity.LEFT, 250, 250);
                    count = 0;
                }else if (count<6){
                    //Log.v("MainActivity", "The value is " + count);
                    classARadio1.setChecked(true);
                    classBRadio2.setEnabled(false);
                    classCRadio3.setEnabled(false);
                    tabHost.setCurrentTabByTag("HCC Staging");
                    pughScore = count;
                    count = 0;

                }else if(count<9){
                    //Log.v("MainActivity", "The value is " + count);
                    classARadio1.setEnabled(false);
                    classBRadio2.setChecked(true);
                    classCRadio3.setEnabled(false);
                    tabHost.setCurrentTabByTag("HCC Staging");
                    pughScore = count;
                    count = 0;
                }else {
                    //Log.v("MainActivity", "The value is " + count);
                    classARadio1.setEnabled(false);
                    classBRadio2.setEnabled(false);
                    classCRadio3.setChecked(true);
                    tabHost.setCurrentTabByTag("HCC Staging");
                    pughScore = count;
                    count = 0;
                }

            }

        });
        /**
         * On click listener for get stage button
         *
         */
        getStage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // class
                if (childPughRadioGroup.getCheckedRadioButtonId() != -1 &&
                        noduleRadioGroup.getCheckedRadioButtonId() != -1 &&
                        portalVeinInvasionRadioGroup.getCheckedRadioButtonId() != -1 &&
                        RLNMRadioGroup.getCheckedRadioButtonId() != -1 &&
                        DMRadioGroup.getCheckedRadioButtonId() != -1 &&
                        EPRadioGroup.getCheckedRadioButtonId() != -1){


                    if (classARadio1.isChecked() &&
                            noduleRadio1.isChecked() &&
                            portalRadio2.isChecked() &&
                            RLNMRadio2.isChecked() &&
                            DMRadio2.isChecked() &&
                            EPRadio1.isChecked()){

                        ShowPopup(getStage,"Child Pugh Score: " + pughScore + "\n"
                                + "Child Pugh Class: " + classARadio1.getText() + "\n"
                                + "Number of Nodules: " + noduleRadio1.getText() + "\n"
                                + "Portal Vein Invasion: " + portalRadio2.getText() + "\n"
                                + "RLNode Metastasis: " + RLNMRadio2.getText() + "\n"
                                + "Distant Metastasis: " + DMRadio2.getText() + "\n"
                                + "ECOG PS: " + EPRadio1.getText() + "\n"
                                , "Very early Stage 0 \n" );

                    }else if(classARadio1.isChecked() &&
                            noduleRadio2.isChecked() &&
                            portalRadio2.isChecked() &&
                            RLNMRadio2.isChecked() &&
                            DMRadio2.isChecked() &&
                            EPRadio1.isChecked()){

                        ShowPopup(getStage,"Child Pugh Score: " + pughScore + "\n"
                                + "Child Pugh Class: " + classARadio1.getText() + "\n"
                                + "Number of Nodules: " + noduleRadio2.getText() + "\n"
                                + "Portal Vein Invasion: " + portalRadio2.getText() + "\n"
                                + "RLNode Metastasis: " + RLNMRadio2.getText() + "\n"
                                + "Distant Metastasis: " + DMRadio2.getText() + "\n"
                                + "ECOG PS: " + EPRadio1.getText() + "\n"
                                , "Early Stage A \n" );

                    }else if(classARadio1.isChecked() &&
                            noduleRadio3.isChecked() &&
                            portalRadio2.isChecked() &&
                            RLNMRadio2.isChecked() &&
                            DMRadio2.isChecked() &&
                            EPRadio1.isChecked()){

                        ShowPopup(getStage,"Child Pugh Score: " + pughScore + "\n"
                                + "Child Pugh Class: " + classARadio1.getText() + "\n"
                                + "Number of Nodules: " + noduleRadio3.getText() + "\n"
                                + "Portal Vein Invasion: " + portalRadio2.getText() + "\n"
                                + "RLNode Metastasis: " + RLNMRadio2.getText() + "\n"
                                + "Distant Metastasis: " + DMRadio2.getText() + "\n"
                                + "ECOG PS: " + EPRadio1.getText() + "\n"
                                , "Early Stage A \n" );

                    }else if (classBRadio2.isChecked() &&
                            noduleRadio2.isChecked() &&
                            portalRadio2.isChecked() &&
                            RLNMRadio2.isChecked() &&
                            DMRadio2.isChecked() &&
                            EPRadio1.isChecked()){

                        ShowPopup(getStage,"Child Pugh Score: " + pughScore + "\n"
                                + "Child Pugh Class: " + classBRadio2.getText() + "\n"
                                + "Number of Nodules: " + noduleRadio2.getText() + "\n"
                                + "Portal Vein Invasion: " + portalRadio2.getText() + "\n"
                                + "RLNode Metastasis: " + RLNMRadio2.getText() + "\n"
                                + "Distant Metastasis: " + DMRadio2.getText() + "\n"
                                + "ECOG PS: " + EPRadio1.getText() + "\n"
                                , "Early Stage A \n" );

                    }else if (classBRadio2.isChecked() &&
                            noduleRadio3.isChecked() &&
                            portalRadio2.isChecked() &&
                            RLNMRadio2.isChecked() &&
                            DMRadio2.isChecked() &&
                            EPRadio1.isChecked()){

                        ShowPopup(getStage,"Child Pugh Score: " + pughScore + "\n"
                                + "Child Pugh Class: " + classBRadio2.getText() + "\n"
                                + "Number of Nodules: " + noduleRadio3.getText() + "\n"
                                + "Portal Vein Invasion: " + portalRadio2.getText() + "\n"
                                + "RLNode Metastasis: " + RLNMRadio2.getText() + "\n"
                                + "Distant Metastasis: " + DMRadio2.getText() + "\n"
                                + "ECOG PS: " + EPRadio1.getText() + "\n"
                                , "Early Stage A \n" );

                    }else if (classARadio1.isChecked() &&
                            noduleRadio4.isChecked() &&
                            portalRadio2.isChecked() &&
                            RLNMRadio2.isChecked() &&
                            DMRadio2.isChecked() &&
                            EPRadio1.isChecked()){

                        ShowPopup(getStage,"Child Pugh Score: " + pughScore + "\n"
                                + "Child Pugh Class: " + classARadio1.getText() + "\n"
                                + "Number of Nodules: " + noduleRadio4.getText() + "\n"
                                + "Portal Vein Invasion: " + portalRadio2.getText() + "\n"
                                + "RLNode Metastasis: " + RLNMRadio2.getText() + "\n"
                                + "Distant Metastasis: " + DMRadio2.getText() + "\n"
                                + "ECOG PS: " + EPRadio1.getText() + "\n"
                                , "Intermediate Stage B \n" );



                    }else if (classBRadio2.isChecked() &&
                            noduleRadio4.isChecked() &&
                            portalRadio2.isChecked() &&
                            RLNMRadio2.isChecked() &&
                            DMRadio2.isChecked()&&
                            EPRadio1.isChecked()){

                        ShowPopup(getStage,"Child Pugh Score: " + pughScore + "\n"
                                + "Child Pugh Class: " + classBRadio2.getText() + "\n"
                                + "Number of Nodules: " + noduleRadio4.getText() + "\n"
                                + "Portal Vein Invasion: " + portalRadio2.getText() + "\n"
                                + "RLNode Metastasis: " + RLNMRadio2.getText() + "\n"
                                + "Distant Metastasis: " + DMRadio2.getText() + "\n"
                                + "ECOG PS: " + EPRadio1.getText() + "\n"
                                , "Intermediate Stage B \n" );


                    }else if (classARadio1.isChecked() &&
                            noduleRadio5.isChecked() &&
                            portalRadio1.isChecked() &&
                            RLNMRadio1.isChecked() &&
                            DMRadio1.isChecked() &&
                            EPRadio2.isChecked()){

                        ShowPopup(getStage,"Child Pugh Score: " + pughScore + "\n"
                                + "Child Pugh Class: " + classARadio1.getText() + "\n"
                                + "Number of Nodules: " + noduleRadio5.getText() + "\n"
                                + "Portal Vein Invasion: " + portalRadio1.getText() + "\n"
                                + "RLNode Metastasis: " + RLNMRadio1.getText() + "\n"
                                + "Distant Metastasis: " + DMRadio1.getText() + "\n"
                                + "ECOG PS: " + EPRadio2.getText() + "\n"
                                , "Advanced Stage C \n" );


                    }else if (classBRadio2.isChecked() &&
                            noduleRadio5.isChecked() &&
                            portalRadio1.isChecked() &&
                            RLNMRadio1.isChecked() &&
                            DMRadio1.isChecked() &&
                            EPRadio2.isChecked()){

                        ShowPopup(getStage,"Child Pugh Score: " + pughScore + "\n"
                                + "Child Pugh Class: " + classBRadio2.getText() + "\n"
                                + "Number of Nodules: " + noduleRadio5.getText() + "\n"
                                + "Portal Vein Invasion: " + portalRadio1.getText() + "\n"
                                + "RLNode Metastasis: " + RLNMRadio1.getText() + "\n"
                                + "Distant Metastasis: " + DMRadio1.getText() + "\n"
                                + "ECOG PS: " + EPRadio2.getText() + "\n"
                                , "Advanced Stage C \n" );


                    }else if (classCRadio3.isChecked() &&
                            noduleRadio5.isChecked() &&
                            portalRadio1.isChecked() &&
                            RLNMRadio1.isChecked() &&
                            DMRadio1.isChecked() &&
                            EPRadio3.isChecked()){

                        ShowPopup(getStage,"Child Pugh Score: " + pughScore + "\n"
                                + "Child Pugh Class: " + classCRadio3.getText() + "\n"
                                + "Number of Nodules: " + noduleRadio5.getText() + "\n"
                                + "Portal Vein Invasion: " + portalRadio1.getText() + "\n"
                                + "RLNode Metastasis: " + RLNMRadio1.getText() + "\n"
                                + "Distant Metastasis: " + DMRadio1.getText() + "\n"
                                + "ECOG PS: " + EPRadio3.getText() + "\n"
                                , "Terminal Stage D \n" );


                    }else if (classCRadio3.isChecked() &&
                            noduleRadio5.isChecked() &&
                            portalRadio2.isChecked() &&
                            RLNMRadio2.isChecked() &&
                            DMRadio2.isChecked() &&
                            EPRadio3.isChecked()){

                        ShowPopup(getStage,"Child Pugh Score: " + pughScore + "\n"
                                + "Child Pugh Class: " + classCRadio3.getText() + "\n"
                                + "Number of Nodules: " + noduleRadio5.getText() + "\n"
                                + "Portal Vein Invasion: " + portalRadio2.getText() + "\n"
                                + "RLNode Metastasis: " + RLNMRadio2.getText() + "\n"
                                + "Distant Metastasis: " + DMRadio2.getText() + "\n"
                                + "ECOG PS: " + EPRadio3.getText() + "\n"
                                , "Terminal Stage D \n" );

                    }else {
                        Toast toast = Toast.makeText(MainActivity.this, "Please check all the right options.", Toast.LENGTH_SHORT);
                        toast.show();
                        toast.setGravity(Gravity.TOP|Gravity.LEFT, 250, 250);

                    }



                }

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.main, menu);

        return super.onCreateOptionsMenu(menu);
    }

    public void ShowPopup(View v , String rt, String rat){
        TextView textClose, stageResult, radioInfo;
        myDialog.setContentView(R.layout.custompopup);
        textClose = myDialog.findViewById(R.id.textClose);
        stageResult = myDialog.findViewById(R.id.stageResult);
        radioInfo = myDialog.findViewById(R.id.radioInfo);
        stageResult.setText(rat);
        radioInfo.setText(rt);
        textClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myDialog.dismiss();
            }
        });
        myDialog.show();
    }
}
